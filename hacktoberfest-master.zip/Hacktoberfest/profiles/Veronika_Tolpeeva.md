# Veronika Tolpeeva

### Location

Moscow, Russia

### Academics

Plekhanov Russian University of Econimics 

### Interests

- Travelling, programming, movies

### Development

- Web developer

### Projects

- [FCC studying](https://github.com/ostyq/FCC_studying) Solutions to Free Code Camp challenges for tracking my progress and public learning


### Profile Link

[Veronika Tolpeeva](https://github.com/ostyq)