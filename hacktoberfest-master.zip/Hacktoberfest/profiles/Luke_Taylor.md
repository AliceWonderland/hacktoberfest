# Luke Taylor

### Location

Derby, UK

### Academics

- NCN Nottingham College
- NW Kent College
- Derby College

### Interests

- Javascript-Based Technologies
- Mobile Applications
- Node, Express, React/Redux, React-Native, MongoDB
- Rock music
- Computer games (RPGs and First-persons)

### Development

- Senior Software Engineer

### Projects

- [Kulor](http://lmcjt.com/kulor/) A tool to help developers and designers convert between different colour modes.

### Profile Link

[Luke Taylor](https://github.com/lmcjt37)
