# Giani 

### Location

Jakarta, Indonesia

### Academics

SMAK 1 Penabur

### Interests

watching tv series

### Profile Link

[akanijade] (https://github.com/akanijade)
