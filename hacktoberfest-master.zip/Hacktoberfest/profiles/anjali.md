# Anjali Bansal

### Location

Delhi, India

### Academics

Presently pursuing MCA, University of Delhi

### Interests

- Learning new stuff

### Profile Link

[Anjali Bansal](https://github.com/bansalanjali2512)