# Gehazi Bispo

### Location

São Cristóvão, SE, Brasil

### Academics

- BA in Psychology ('15) and MS in Behavior Theory and Research ('17). 
- Currently pursuing freeCodeCamp's Full Stack Web Development Certificate.

### Interests

- Web Apps Development
- Mobile Apps Development
- AI and ML
- Behavioral Technologies
- Statistics and Data Analysis
- UI/UX
- Consumer Behavior
- I LOVE COOCKIES!

### Development

- **$** > Full Stack Web Developer in progress... (15%)

### Projects

- none yet :/

### Profile Link

[Gehazi Bispo](https://github.com/gehazibispo)
