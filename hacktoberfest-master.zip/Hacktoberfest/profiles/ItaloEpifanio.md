# Ítalo Epifânio

### Location

Natal/Brazil

### Academics

Bachelor student in Information Technology at UFRN (Federal University of Rio Grande do Norte)

### Interests

- Basketball
- Web Development / Programming
- Guitar
- Music
- Drawing
- History

### Development

- Web Developer

### Projects

- All projects for tech study:

[Crud Laravel](https://github.com/itepifanio/crudLaravel)
[Crud Django](https://github.com/itepifanio/Crud-Django-CBV)
[ITP Class](https://github.com/itepifanio/itpClass)



### Profile Link

[Ítalo Epifânio](https://github.com/itepifanio/)
