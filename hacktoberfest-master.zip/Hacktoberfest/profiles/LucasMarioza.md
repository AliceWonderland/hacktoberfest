# Lucas Marioza

### Location

Belo Horizonte ,MG,Brazil 

### Academics

CEFET - MG

### Interests

- Board Games
- Competitive Programming
- Video Games

### Development

Prefer JS and a little of c++

### Profile Link

[LucasMarioza](https://github.com/LucasMarioza)
