# Matthew Dray

### Academics

Hoover High School

### Interests

- Gaming
- Programming
- Problem Solving
- Mathematics
- Learning
- Game Design
- Computer Science
- Computer Engineering
- Prosthetics

### Development

- Tip Bots for Cryptocurrency Discords
- Website Consulting

### Projects

- Personal Web Browser (will add hopefully later)(WIP)
- Personal Text Editor (will add hopefully later)(WIP)

### Github

[Matthew Dray](https://github.com/17robots)