# Lucas Leandro

### Location

Florianópolis, SC, Brazil.

### Academics

Life

### Interests

- Code.
- Party.
- Learn new stuff.

### Development

- I learned the basics, so I started work at Bulldesk and now I learn what I wan't to.

### Projects

- [Pornsearch](https://github.com/LucasLeandro1204/Pornsearch) Nice lib to get porn.
- [Larahah](https://github.com/LucasLeandro1204/Larahah) Sarahah like using Laravel and Vue.
- [Fontawesome-scrapper](https://github.com/LucasLeandro1204/Fontawesome-scrapper) Font awesome scrapper.

### Profile Link

[LucasLeandro1204](https://github.com/LucasLeandro1204)