# Nawed Imroze

### Location

Bhubaneswar, India

### Academics

IIIT Bhubaneswar

### Interests

- Programming
- Quizzing
- Traveling

### Projects

- [Tribute page for Grace Murray Hopper](https://github.com/nawedx/Gracehopper-tribute) It is a short tribute page that I made as my first web development project.

### Profile Link

[Nawed Imroze](https://github.com/nawedx)
