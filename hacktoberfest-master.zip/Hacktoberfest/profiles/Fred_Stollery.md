# Fred Stollery

### Location

Richland, Washington, United States

### Interests

- Gaming
- Podcasting
- Game Development

### Development
- HTML, CSS, Javascript, some PHP, and JQuery


### Projects

- SmeggCo.com and it's in progress redesign.

### Profile Link

[Fred Stollery](https://github.com/actatus)