# Jia Wei

### Location

Singapore

### Academics

Graduate

### Interests

- Gamining and programming

### Development

- Inventor of nothing yet

### Projects

- Something here

### Profile Link

[Chong Jia Wei](https://github.com/heyjiawei)