# Jackson Isaac

### Location

Mumbai, India

### Academics

Amrita School of Engineering
Technical University of Munich

### Interests

- Blogging
- Piano
- Reading Books (Biographies, Real life stories)

### Development

- Google Summer of Code 2015 student - The MacPorts Project

### Projects

- [Hostel Management System](https://github.com/JacksonIsaac/Hostel-Management-System) Hostel Management System using Java as Front End and PostgreSQL for Back End database management. 
- [InstaFilter](https://github.com/JacksonIsaac/InstaFilter) InstaFilter: An image processing app created as part of Courera iOS App development course using Swift. 

### Profile Link

[Jackson Isaac](https://github.com/JacksonIsaac)
