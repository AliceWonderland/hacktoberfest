# Victor Oluwayemi

### Location

Ile-Ife/Nigeria

### Academics

Student at Obafemi Awolowo University

### Interests

- Music, Aviation and Aerospace Engineering

### Profile Link

[Victor Oluwayemi](https://github.com/AyoOlu1)
