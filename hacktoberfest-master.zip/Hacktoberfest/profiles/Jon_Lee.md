# Jon Lee

## About me:

17 years old student. 

## Certificates:
- None

## Languages that I know:

- HTML
- CSS
- JS
- React

## Frameworks and Technologies that I know:

- Bootstrap
- jQuery
- React
- Node.js
- Express
- Mongoose
- MongoDB

[Check out my GitHub](https://github.com/githubbbbbbbbbbbbb)

Email me: githubbbb@gmail.com
