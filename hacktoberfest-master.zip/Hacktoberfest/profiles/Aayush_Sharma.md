# Aayush Sharma

### Location

Mandi, Himachal Pradesh, India

### Academics

Indian Institute of Technology, Mandi

### Interests

- Mathematics.

### Development

- Restricted Boltzman Machine.
- Support Vector Machine.

### Projects

- Aawaz - A sign language to voice convertor glove for mute people.

### Profile Link

[Aayush Sharma](https://github.com/aayusharma)
