# Nelson Estevão

### Location

Braga, Portugal

### Academics

BSc in Economics
School of Economics & Management
University of Minho

### Interests

- Computer Science
- Puzzles
- Comedy

### Development

- A litle of webdevelopment.

### Profile Link

[Nelson Estevão](https://github.com/nelsonmestevao)
