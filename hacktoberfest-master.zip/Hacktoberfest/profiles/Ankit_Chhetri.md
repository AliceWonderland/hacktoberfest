# Ankit Chhetri

### Location
Kathmandu, Nepal 

### Academics
Undergraduate in BSc.(Hons) Computing

### Interests
- Javascript
- Android 
- Python
- Memes

### Development
- Backend Developement | Snake Charmer | Student

### Profile Link
[Github Link](https://github.com/ankitch)