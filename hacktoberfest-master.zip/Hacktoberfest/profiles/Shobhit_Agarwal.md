# Shobhit Agarwal

### Location

JSSATE, NOIDA, India

### Academics

Undergraduating in Computer Science from College of Engineering, JSSATE NOIDA.

### Interests

- Competitve Coding
- Android App Developmnt
- Travelling

### Development

- Working as a intern in eninov systems on hybrid app development. 
- Love Creating Android utility apps and games

### Projects

- [QuizBox](https://github.com/shobhit1997/QuizBox.git) A quiz game with different features like buzzer round.
- [Tia Tac Toe](https://github.com/shobhit1997/Tic_Tac_Toe-Realtime-Multiplayer.git) A realtime multiplayer tic tac toe.


### Profile Link

[Shobhit Agarwal](https://github.com/shobhit1997/)
