# Shaun O'Connor

### Location

Galway, Ireland

### Academics

Athlone Institute of Technology

### Interests

- Love coding, playing football, meeting friends :-)

### Development

- A lot of small projects that I never seem to finish :(

### Projects

- [Travel Smart Ireland](https://github.com/shaunoc09/travel-smart-ireland) A travel dashboard for public transport in Ireland. (Currently just Dublin Bus)


### Profile Link

[Shaun O'Connor](https://github.com/shaunoc09)