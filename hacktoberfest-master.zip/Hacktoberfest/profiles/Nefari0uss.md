# Your Name

Nefari0uss

### Location

United States of America

### Interests

* Game Development
* AI
### Projects

- [Dotfiles](https://github.com/nefari0uss/dotfiles) 

My Dotfiles repo is a collection of my config and various `rc` files. 

### Profile Link

[Nefari0uss](https://www.github.com/nefari0uss)
