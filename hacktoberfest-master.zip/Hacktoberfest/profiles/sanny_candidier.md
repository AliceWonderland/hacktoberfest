# Sanny Candidier

### Location

Davao City, Philippines

### Academics

Ateneo de Davao University 

### Interests

- Singing
- Biking

### Development

- Worked on several projects for companies with private repos

### Projects

- Everything has been on private repos.

### Profile Link

[Sanny Candidier](https://github.com/sannycand)
