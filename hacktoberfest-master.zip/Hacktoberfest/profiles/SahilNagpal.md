Sahil Nagpal

### Location

New Delhi, India

### Academics

Manipal Institute of Technology

### Profile Link

[Sahil Nagpal](github.com/sahil2598)
