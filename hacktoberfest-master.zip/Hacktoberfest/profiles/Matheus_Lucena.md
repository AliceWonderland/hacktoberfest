# Matheus Lucena

### Location

- Brazil

### Academics

Computer Science at Fumec

### Interests

- Ruby on Rails
- Software Engineer
- Agile

### Development

- Trying to learn more deeply Spring stuffs.

### Projects

- None right now.

### Profile Link

[Matheus Lucena](https://github.com/matehuslucena)
