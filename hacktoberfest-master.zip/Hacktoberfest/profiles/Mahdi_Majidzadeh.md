# Mahdi Majidzadeh

### Location

Qom/Iran

### Academics

Qom University

### Development

- founder at https://qomfood.ir

### Projects

- [bootstrap-v4-rtl](https://github.com/MahdiMajidzadeh/bootstrap-v4-rtl) bootstrap v4 rtl

### Profile Link

[Mahdi Majidzadeh](https://github.com/MahdiMajidzadeh/)
[Mahdi Majidzadeh](https://twitter.com/MahdiMajidzadeh/)
