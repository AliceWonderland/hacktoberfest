# Alina Christenbury

### Location

Newark, DE

### Academics

Computer Science B.S. at the University of Delaware, expected graduation in Spring 2019

### Interests

- Humans vs Zombies / Nerf Wars
- Video editing and animation
- VR
- Video games, with a focus on far too much Animal Crossing / Overwatch
- Sustainability in the face of inevitable automation
- Cooking
- Reddit

### Development

- Mostly school projects so far, but I've played with Unity a little bit

### Projects

- Private repos from internships
- *Tons* of lab work from school

### Profile Link

[AlinaWithAFace](https://github.com/AlinaWithAFace)