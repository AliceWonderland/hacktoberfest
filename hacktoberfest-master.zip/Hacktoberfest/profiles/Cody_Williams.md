# Cody Williams

### Location

Dallas, TX, USA

### Academics

Who needs college? :P

### Interests

- JavaScript
- Node, Express, Angular2/4
- Data Science
- Skateboarding
- Music

### Development

- Full Stack Web Developer

### Projects

- [skateSpots](https://github.com/codyw9524/skateSpots) A web app designed to allow users to share street skating locations.

### Profile Link

[Cody Williams](https://github.com/codyw9524)