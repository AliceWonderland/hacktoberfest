# Your Name
J. Fehrman

### Location
Virginia

Your City/Country
United States

### Academics
University of Mary Washington

### Interests

- Coding
- Meditation
- Learning

### Development

- Vimpossible
- Humdrum Components
- extend

### Projects

- [Vimpossible](https://github.com/jfehrman/Vimpossible) Short Description
- [Humdrum Components](https://github.com/jfehrman/humdrum-components)
- [extend](https://github.com/jfehrman/extend)

### Profile Link

[jfehrman](https://github.com/jfehrman)
