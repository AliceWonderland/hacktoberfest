# Dennis Orzikh

### Location
Seattle, WA. LA, CA before that. Tampa, FL before that. NYC, NY before that. ??? before that.

### Academics
4th year student at University of Washington. Likes AI stuff, data analysis stuff, hating Microsoft (who doesn't?)

### Interests
- [x] Plays videogames
- [x] Thinks he is good at videogames
- [x] Typically stops playing a game once he realizes he is bad at it
- [x] Plays D&D (5e) weekly when possible
- [x] Takes on the difficult task of DMing because no one else will and it's more fun than not playing D&D at all
- [x] Satisfied sharing satire, sarcasm, and amazing alliteration

### Development
Yes :sparkles:

### Projects
[Github Link](https://github.com/orzikhd)
