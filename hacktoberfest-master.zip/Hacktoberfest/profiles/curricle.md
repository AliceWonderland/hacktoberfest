# S. Jordan

### Location

New Jersey, USA

### Academics

B.A. in Digital Design from NJIT

### Interests

- Art
- Music
- Video games
- Technology
- Animals

### Development

- Working on websites, apps, and games with HTML, CSS, and Javascript

### Projects

- [turnbased](https://github.com/curricle/turnbased) - a turn-based battle system in the works, inspired by Fire Emblem.

### Profile Link

[curricle](https://github.com/curricle)
