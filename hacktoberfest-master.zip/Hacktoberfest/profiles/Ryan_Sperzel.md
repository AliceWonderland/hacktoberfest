# Ryan Sperzel

### Location

NYC, NY, USA

### Academics

Flatiron School
Marist College

### Interests

- Coding!
- Everything Miyazaki
- Dogs
- Ping Pong
- Horror Movies

### Development

- Dev in Training

### Projects

- [Clownslist]https://github.com/ryansperzel/mod-2-final-project Mock 'party planning craigslist' project I made for school with two colleagues

### Profile Link

[Ryan Sperzel](https://github.com/ryansperzel)
