# Drix Lopez

### Location

Quezon City, Philippines

### Academics

University of the Philippines - Diliman

### Interests

-I like playing guitar
-I like listening to covers in YouTube
-I like coding

### Development

-Done a couple of freecodecamp projects


### Profile Link

[@gabrielslach](https://github.com/gabrielslach)
