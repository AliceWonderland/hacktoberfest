# Akshat Maheshwari

### Location

Hyderabad, India

### Academics

B.Tech. in Computer Science and Engineering, IIIT Hyderabad (2016-current)

### Development

- C++
- JavaScript
- Python
- HTML/CSS/Bootstrap
- Ruby on Rails
- Flask
- Django

### Profile Link

[akshat14714](https://github.com/akshat14714/)
