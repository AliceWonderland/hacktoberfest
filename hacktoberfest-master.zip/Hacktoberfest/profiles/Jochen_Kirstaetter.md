# Jochen Kirstätter

### Location

Flic En Flac, Mauritius

### Academics

School of Life

### Interests

- Family guy, geek, entrepreneur, software craftsman: Microsoft MVP Visual Studio, C#, Xamarin, SQL Server, VFP, MySQL, Linux consultant, conference speaker

### Development

- Founder of the [Mauritius Software Craftsmanship Community (MSCC)](https://www.mscc.mu/) which is the largest and most active IT user group in Mauritius.

### Projects

- [mscc-ghost](https://github.com/mscraftsman/mscc-ghost) Ghost theme used on MSCC website
- [devcon2017](https://github.com/mscraftsman/devcon2017) Website of Developers Conference 2017 in Mauritius
- [devcon2016](https://github.com/mscraftsman/devcon2016) Website of Developers Conference 2016 in Mauritius
- [devcon2015](https://github.com/mscraftsman/devcon2015) Website of Developers Conference 2015 in Mauritius

### Profile Link

[jochenkirstaetter](https://github.com/jochenkirstaetter)