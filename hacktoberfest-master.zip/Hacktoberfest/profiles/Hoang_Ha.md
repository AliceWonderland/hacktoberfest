# Hoang Ha

### Location

Hanoi/Vietnam

### Academics

University of Engineering and Technology, Vietnam National University, Hanoi

### Interests

- The Martian, Linkin Park, My Filco Minila Air

### Development

- Work then I can sleep tight

### Projects

- [Hugo Desktop App](https://github.com/halink0803/hugo-desktop-app) Desktop application to manage Hugo sites
- [VN-Vuejs](https://github.com/vuejs-vn/vuejs.org) Localize vuejs.org site to Vietnamese

### Profile Link

[Hoang Ha](https://github.com/halink0803)