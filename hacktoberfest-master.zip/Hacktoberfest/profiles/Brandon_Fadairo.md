# Brandon Fadairo

### Location

Columbus, OH USA

### Interests
- Computers
- Programming
- Finance

### Development
- Currently in the beginner stage
- Developing my skills as a programmer

### Projects
- Learning Python, Java after I'm comfortable enough

### Profile Link

<a href ='https://github.com/BFadairo'>BFadairo</a>


