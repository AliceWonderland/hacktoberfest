# Santanaraj Esguerra

### Location
-Juliana Subdivision, City of San Fernando Pampanga PH 2000

### Academics
-Our Lady of Fatima University Pampanga College of Computer Studies

### Interests
-Animation
-Graphics Designing
-Game Developing
-Piano
-MMORPG/RPG.

### Development
-Developed Personal Games.

### Projects
-Only have Gist on Github [https://gist.github.com/akiyamamio16/2c5e53bf7f70bb82e89461cdb1fd7264] - rathena script

### Profile Link
-[Santanaraj Esguerra](https://github.com/akiyamamio16)