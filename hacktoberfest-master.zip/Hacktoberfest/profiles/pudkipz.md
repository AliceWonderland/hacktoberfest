# Mat.

### Location

Stockholm, Sweden

### Academics

Last year of gymnasium/high school

### Interests

- Making music
- Making games
- Learning new things

### Development

- Creating small hobby projects.

### Projects

- [CryptoGame](https://github.com/pudkipz/CryptoGame) Game about cryptography with pygame, created with a friend.

### Profile Link

[Mat.](https://github.com/pudkipz)