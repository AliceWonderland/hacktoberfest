# Momme Jürgensen

### Location

Niebüll/Germany

### Academics

Gemeinschaftschule Niebüll

### Interests

- play games
- swim

### Development

- [feathers-bee](https://github.com/codeanker/feathers-bee)
- [feathers-elastic-logger](https://github.com/supermomme/feathers-elastic-logger)

### Projects

- [Project Management](https://github.com/supermomme/project-management-client) A Project Management Tool. Just for learing :)

### Profile Link

[Momme Jürgensen](https://github.com/supermomme)
