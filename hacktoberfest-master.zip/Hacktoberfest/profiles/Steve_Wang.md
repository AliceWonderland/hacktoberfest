Steve
Wang

### Location

Evanston. IL

### Academics

Northwestern University *Go 'Cats*


### Interests

Marvel

### Projects

- New Materials for Quantum Hall Effect
- Band Gap Engineering in Topological Insulators

### Profile Link

PureHyd
https://github.com/PureHyd
