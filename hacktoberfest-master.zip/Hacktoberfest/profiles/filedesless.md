# Filedesless

### Location

Québec city, QC, CA

### Academics

- DCS's in programming and network management.
- Currently enrolled in Computer Science Bachelor's degree from Université Laval

### Interests

- Security
- Web dev
- Game dev

### Development

- Frontend UI Engineer, Fullstack Software Engineer

### Projects

- [HTLL](https://hightechlowlife.info) A forum for security enthusiasts and other computer lovers
- [Fuyuko's Adventure](https://github.com/aiglebleu/Fuyuko) A functionning game prototype written in Haxe

### Profile Link

[aiglebleu](https://github.com/aiglebleu)