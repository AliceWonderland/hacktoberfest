# Pronomita Dey

### Location : Bhubaneswar, India

### Academics

7th sem CSE undergrad. Expected grad: April'18

### Interests
- Data Structure
- Algorithm Designing
- OSS
- Crime Thrillers 
- Competetive Programming

### GitHub : [Pronomita Dey] (https://github.com/PronomitaDey)

