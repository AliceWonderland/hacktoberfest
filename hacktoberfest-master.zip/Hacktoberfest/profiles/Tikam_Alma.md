# Tikam Alma

### Academics

DAIICT-Gandhinagar,Gujarat.

### Location 

Ahemdabad,India

### Academics

CSE And Information Technology.

### Intrests 

Portrait Drawing, Basketball And Travelling.

### Development

Django-Fullstack-Developer
Node-Developer
Security-Engineer 
FullStack Web-App Developer

### Projects

OWASP-Code-Sprint-2017

### ProfileLink

[Tikam Alma](https://github.com/Tikam02)
