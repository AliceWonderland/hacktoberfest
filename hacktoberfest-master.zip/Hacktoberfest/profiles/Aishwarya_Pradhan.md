# Aishwarya Pradhan

## About me:

My name is Aishwarya Pradhan and I live proudly in India. I am a Learner, Coder,  INFJ, multipotentialite and a person who loves to explore life. Professionally, I am a Python/Django Developer. I love computers and has a keen interest in them. Anything related to them makes me curious. Other than that I think about complex things like how the universe was created to silly things like what I am gonna eat in dinner. I am a person who loves to dream and write.

## Certificates:
- Not anything worth showing. I am more of a free learner.

## Languages that I know:

- HTML
- CSS
- JS
- Python
- C
- Java


## Frameworks and Technologies that I know:

- Bootstrap
- jQuery
- Django
- Wordpress



[Check out my GitHub](https://github.com/aishwaryapradhan)
[Check out my Website for non - technical stuff](http://introvertedgeek.com)

Email me: aishwaryapradhan82[at]gmail[dot]com


