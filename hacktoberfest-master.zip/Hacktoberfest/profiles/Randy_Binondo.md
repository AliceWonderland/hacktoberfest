# Randy D. Binondo

### Location

Mandaue City, Cebu, Philippines

### Academics

CIT-University
CITE Technical Institute, Inc.

### Interests

- Internet of Things.
- Full Stack Software Development.
- Software Engineering..
- Robotics.

### Development

- Front-end apps with AngularJS/Angular.
- Back-end apps with Node/Express/Laravel/PHP/Python.
- Mobile apps (Android/iOs).

### Projects

- WeJustDevelop - An opensource networking site for developers.

### Profile Link

[Randy D. Binondo](https://github.com/binondord)
