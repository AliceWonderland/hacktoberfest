# Sai Sankar Gochhayat

### Location

Bhubaneswar, Odisha, India

### Academics

Undergraduating in Computer Science from College of Engineering and Technology, Bhubaneswar.

### Interests

- Web development
- Image Processing
- Machine Learning
- Gaming
- Partying

### Development

- I've worked as a Google Summer of Code Intern at AOSSIE.
- Love Creating APIs and Bots

### Projects

- [CarbonFootprintAPI](https://gitlab.com/aossie/CarbonFootprint-API) A CarbonFootprint API.

A partially complete list can be found [here](https://saisankar.ml).

### Profile Link

[Ishan Jain](https://saisankar.ml)
