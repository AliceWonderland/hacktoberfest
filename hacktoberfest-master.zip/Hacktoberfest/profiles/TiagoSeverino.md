# Your Name

Tiago Severino

### Location

Lisbon, Portugal

### Academics

Undergraduated

### Interests

I code for fun!

### Development

C#, HTML, CSS, JavaScript, Node.js, Java, Python and currently learning Ruby.

### Profile Link

[TiagoSeverino](https://github.com/TiagoSeverino)