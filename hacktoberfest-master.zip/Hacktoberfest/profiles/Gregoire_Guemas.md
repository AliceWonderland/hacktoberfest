# Grégoire Guémas

### Location

Quebec, Canada

### Academics

Epitech Paris && currently in exchange at Université Laval de Québec

### Interests

- Mathematics.
- Web development.
- Scala && functional programming.

### Development

- Many express and shell script 

### Projects

- Currently working on an anti cheat for Minecraft server

### Profile Link

[Grégoire Guémas](https://github.com/navispeed)
