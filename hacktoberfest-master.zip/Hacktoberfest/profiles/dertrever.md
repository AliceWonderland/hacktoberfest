# dertrever

### Location

Berlin, Germany

### Academics

B. Sc. Information Systems Engineering

### Interests

- Breaking Bad
- Piano

### Development

- Java, Java EE, Python

### Projects

- none yet, working on a text editor

### Profile Link

[dertrever](https://github.com/dertrever)
