# Benjamin Van Renterghem

### Academics

- Howest Bruges (BE)
- Tecnológico de Monterrey campus Querétaro

### Interests

- Drums
- Basketball

### Projects

- [Jungle Wars](https://github.com/BenjaVR/Jungle-Wars) LibGDX game about Harambe.


### Profile Link

[BenjaVR](https://github.com/BenjaVR)