# Gabe Dunn

### Interests

- Programming, swimming, and TV shows.

### Development

- Core team of markd bookmark tool

### Projects

- [markd](https://github.com/markd/markd) Open source bookmark manager.
- [when.](https://github.com/redxtech/when) Website to track tv show release dates using vue & trakt.tv API.

### Profile Link

[Gabe Dunn](https://github.com/redxtech)