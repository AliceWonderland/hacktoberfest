# Mark Carlson

### Location

Chicago, IL, USA

### Academics

BS in Electrical Engineering from Old Dominion University

### Interests

- Microcontroller-based projects of all kinds
- Mexican food (making and of course eating)
- Read tons of books (mainly sci-fi and fantasy, with a smattering of other genres)

### Development

- HW Engineer

### Projects

- Built a Time Machine (ok, it's just a prop, but still...)
- Other micro-based props

### Profile Link

[Mark Carlson](https://github.com/electrek)