# Gleb Ermolaev

### Location

Moscow, Russia

### Academics

MIREA, Russia

### Interests

Coding, Starbucks coffee, basketball

### Development

I managed to write a server on C!!

### Projects

[Website](https://github.com/Ermolaeff/Ermolaeff.github.io) A tiny web experience I had
[Converter](https://github.com/Ermolaeff/homework) A temperature Converter in pure C

### Profile link

[Gleb Ermolaev](https://github.com/Ermolaeff)
