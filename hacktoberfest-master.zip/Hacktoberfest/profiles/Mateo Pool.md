# Mateo Pool

### Location

Chattanooga, TN, USA

### Academics

I've been homeschooled my whole life

### Interests

<ul>
  <li>Computer Science</li>
  <li>Penetration Testing</li>
  <li>Mathematics</li>
</ul>

### Development

- Display system for local Chick-fil-a
- ScreenAwake on the chrome web store

### Projects

- [File sizer](https://github.com/IAmMyself/file-sizer) Checks the size of file
- [Polls](https://github.com/IAmMyself/polling-app) Hosts polls
- [URL shortener](https://github.com/IAmMyself/cutURL) Shortens urls
- [Search](https://github.com/IAmMyself/imgsearch) Image search abstraction layer using Bing Image API
- [Responce Header Parser](https://github.com/IAmMyself/rhp-fcc) Parces Responce Headers
- [Time](https://github.com/IAmMyself/fcc-timestamp-iamyself) Converst from Unix to Natural, or vice-versa



### Profile Link

[Mateo Pool](https://github.com/IAmMyself)
