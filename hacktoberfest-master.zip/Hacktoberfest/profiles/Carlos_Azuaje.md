# Carlos Azuaje

### Location

Venezuela

### Interests

- Music Producer
- Programming
- Contributing to open source projects

### Development

- Web Developer

### Projects

- [Talkcode](https://github.com/CharlyJazz/TalkCode) Web app made in Flask with de power of SocketIO, Redis, SQLAlchemy and more.
- [Flask MVC Template](https://github.com/CharlyJazz/Flask-MVC-Template) Flask-MVC Template It is a template with "batteries included" created for the fast development of applications in the microframework flask.
- [Sinata + Sequel + Backbone](https://github.com/CharlyJazz/Sinatra-Sequel-Backbone) App made in Sinatra with de power of Sequel and Backbone.

### Profile Link

[Carlos Azuaje](https://github.com/CharlyJazz)