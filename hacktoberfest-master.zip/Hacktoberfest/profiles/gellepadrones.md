# Your Name

Gelle Padrones

### Location

Philippines

### Academics

De La Salle University

### Interests

PC/Console Games, Programming, Video Editing/Recording

### Development

- License Plate Recognition for Philippine License Plates

### Projects

- [Smart Parking System with NFC Payment System and Semi-Automated Slot Allocation](no_link) a smart parking system with an android application for driver's to monitor the parking lot's occupancy.

### Profile Link

[Gelle Padrones](https://github.com/aegelle31)
