# Chathumina Vimukthi

## About me:

21 years old and second year CS Engineering student from Srilanka. I love maths,physics and to learn new techs like machine learning.

## Languages that I know:

- HTML
- CSS
- JS
- Java
- C++
- Mysql
- Bash

## Frameworks and Technologies that I know:

- Bootstrap
- jQuery
- React
- Node.js
- Express
- Mongoose
- MongoDB
- Oculus rift
- Android
- Eclipse

[Check out my GitHub](https://github.com/ChathuminaVimukthi)
