# Anuj Raval
### Location

- Gujarat , IN
### Academics

- Computer Engineering @ Alpha College Of Engg. & Tech.

### Interests

- Home Automation, IOT , AI , Blockchain , Football , Java Programming 

### Development

- Self Taught Programmer

### Projects

- [jMessenger](https://github.com/Anujraval24/jMessenger) JMessenger is conceptualized and is based on the Communication nature of Human Being and is an attempt to make the communication better
### Profile Link

[Anuj Raval](https://github.com/anujraval24)
