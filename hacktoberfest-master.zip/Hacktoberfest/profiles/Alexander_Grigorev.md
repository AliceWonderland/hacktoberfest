# Aleksander Grigorev

### Location

Russia, Moscow

### Academics

Kazan Federtal University

### Interests

- chekers
- php7

### Development

- Backend Web Developer

### Projects

- [rotorcms](https://github.com/visavi/rotor) Mobile site management system

### Profile Link

[Aleksander Grigorev](https://github.com/visavi)
