# Damodar Lohani

### Location

Kathmandu, Nepal

### Academics

Tribhuvan University

### Interests

- Art and Craft
- Video Games
- French

### Development

- Mobile Applications and Web Applications are primary focus

### Projects

- [OpenPics](https://github.com/lohanitech/openpics)
- [Ionic3Components](https://github.com/lohanidamodar/ionic3-components)

### Profile Link

[Damodar Lohani](https://github.com/lohanidamodar)
