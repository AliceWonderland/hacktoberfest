# Joscha
### Location 
Vancouver, WA, USA
### Academics
Washington State University Vancouver
### Interests
I like Dnd, Games, Nice People, forests, red pandas, space, and giant pandas.
### Development
Gonna work at Amazon soon. and student person
### Projects 
 Soon to be a Python SCII AI
### Link
[JoschaO](https://github.com/JoschaO)
