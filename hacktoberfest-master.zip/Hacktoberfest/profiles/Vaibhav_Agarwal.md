# Vaibhav agarwal

### Location

Mandi, Himachal Pradesh, India

### Academics

IIT Mandi (Computer Science & ENgineering)

Central Academy ( CBSE 10+2 ) 

### Interests

- Artificial Intelligence
- Programming
- Listening to music
- Hanging out with friends

### Development

- Inventor of CodeSpace

### Projects

- [CodeSpace](https://github.com/vaibhavagarwal220/codespace) It​ ​is​ ​a​ ​platform​ ​​to​ ​test​ ​programs​ ​and​ ​organize​ ​competitive programming​ ​contests.The​ ​system​ ​can​ ​compile​ ​and execute​ ​code,​ ​and​ ​test​ ​them​ ​with​ ​pre-constructed ​data.
- [Cinephilia](https://github.com/vaibhavagarwal220/cinephilia) A ​web ​app​ ​to​ ​sort​ ​your​ ​movies​ ​according​ ​to​ ​their​ ​IMDb ratings​ ​and​ ​genres.​ ​It​ ​also​ ​keep​ ​tracks​ ​of​ ​which​ ​movies you've​ ​watched​ ​and​ ​suggests​ ​movies​ ​accordingly. 
- [IITMandi​Dashboard](https://github.com/vaibhavagarwal220/dashboard) A​ ​platform​ ​which​ ​has​ ​relevant​ ​posts,​ ​portals​ ​for​ ​course reviews,​ ​timetables,​ ​in-campus​ ​event​ ​calendar,​ ​all​ ​that​ ​is relevant​ ​to​ ​our​ ​campus​ ​in​ ​one​ ​place.


### Profile Link

[Vaibhav Agarwal](https://github.com/vaibhavagarwal220)