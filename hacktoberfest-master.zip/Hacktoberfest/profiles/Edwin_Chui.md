# Edwin Chui

### Location
Georgia, United States

### Academics
CS Degree

### Interests

- HTML
- CSS
- JS
- PHP
- MySQL
- Go
- Coffee :)

### Development

I am a full-time / fullstack web developer in the mountains of Georgia.

### Profile Link
[Github Link](https://github.com/Fly1nP4nda)