# Neelansh Sahai

### Location
Lucknow, Uttar Pradesh, India

### Academics
- High School (X) - Montfort Inter College, Mahanagar, Lucknow
- Intermediate (XII) - Central Academy, Vikas Nagar, Lucknow
- U.G. (Bachelor of Technology) - Indian Institute of Information Technology, Vadodara

### Interests
- Android Development
- Machine Learning
- Python
- Competitive Coding

### Development
- Meme Generator
- Ultron
- TicTacToe

### Projects
- [Glancify](https://github.com/psikarwal/Glancify)
- [Meme Generator](https://github.com/neelanshsahai/MemeGenerator)
- [Ultron](https://github.com/Prakash2403/ultron)
- [ChatOn](https://github.com/neelanshsahai/FriendlyMessagingApp)
- [TicTacToe](https://github.com/Prakash2403/UltimateTicTacToe)

### Profile Link
[Neelansh Sahai](https://github.com/neelanshsahai)
