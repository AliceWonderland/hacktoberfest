# Jacob Coulter

### Location

Akron, Ohio

### Academics

Franciscan University of Steubenville

### Interests

- Teaching people to program.

### Development

- I've tried an awful lot of stacks.

### Projects

- [kidsteaching.tech](http://kidsteaching.tech) 

### Profile Link

[jcoulter](https://github.com/jcoulter)
