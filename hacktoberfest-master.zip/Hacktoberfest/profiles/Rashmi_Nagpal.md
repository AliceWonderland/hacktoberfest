RASHMI NAGPAL
-------------------------------------------------------
LOCATION:
Delhi,India.
ACADEMICS:
I’m in final year at IIIT-D, doing majors in CS and I completed my schooling from HansRaj Model School.
INTERESTS:
Natural Language Processing.
CyberSecurity.
Network Biology.
PROJECTS:
Check out some of my projects on git - https://github.com/RN0311
PROFILE LINK:
https://rashminagpal0311.wordpress.com/
https://www.facebook.com/rashminagpal.nagpal



