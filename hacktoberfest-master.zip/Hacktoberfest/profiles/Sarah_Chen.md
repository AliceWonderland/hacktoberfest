Sarah Chen

### Location

Sao Paulo/ Brazil  

### Academics

FATEC-SP  

### Interests

- UX

### Development

- ...

### Projects

- ...

### Profile Link

[sarovisk]https://github.com/sarovisk
