# Pratyum Jagannath

### Location

Singapore

### Academics

Undergraduated in Computer Engineering.

### Interests

- Coding
- AI and Machine learning
- Opensource Enthusiast

### Development

- Eat Sleep hack repeat.
- Contributing to other opensource projects etc.

### Profile Link

[Pratyum Jagannath](https://github.com/Pratyum/)
