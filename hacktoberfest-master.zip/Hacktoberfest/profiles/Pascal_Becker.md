# Pascal Becker

### Location

Karlsruhe, Germany

### Academics

Karlsruhe Institute of Technology

### Interests

- Robots
- Path planning
- Adventures

### Development

- Open Source developer
- ROS
- Web

### Profile Link

[famalgosner](https://github.com/famalgosner)
