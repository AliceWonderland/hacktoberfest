# Stu Wares

### Location

Tamworth, United Kingdom

### Academics

Front end web development with Free Code Camp and Udacity

### Interests

- Sci-fi
- Cooking

### Development

Many half-finished websites!

### Projects

[Simple Weather App](https://stuwares.github.io/weather/) A simple, responsive weather app.

### Profile Link

[Stu Wares](https://github.com/StuWares/)