# Charles Li

### Location

Vancouver, Canada

### Academics

University of Toronto

### Interests

Programming

### Development

Lisp Visualizer

### Projects

Force-Directed abstract Syntrax Tree Interpreter

### Profile Link

[Charles Li](https://github.com/tigerleapgorge/)

