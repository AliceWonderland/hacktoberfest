# Christopher Bradshaw

### Location

Provo, Utah, USA

### Academics

Brigham Young University

### Interests

- Parkour
- Singing
- Art
- Foxes
- Japanese

### Development

- Contributed to FamilySearch
- Worked on several projects for companies with private repos

### Projects

- Everything has been on private repos for the mostpart... :'(
- But you can see some stuff on my linkedIn (https://www.linkedin.com/in/christophergbradshaw/)

### Profile Link

[Christopher Bradshaw](https://github.com/kitsune7)
