# Ocean

### Location

Henan@China / Hays@USA

### Academics

Fort Hays State University

### Interests

- Chinese Food :heart_eyes:
- Movies :tv:
- Sports :baseball: #GoCubsGo #FlyTheW

### Development

- Future Fullstack Software Developer

### Projects

- Not yet

### Profile Link

[Ocean](https://github.com/ocean0212)
