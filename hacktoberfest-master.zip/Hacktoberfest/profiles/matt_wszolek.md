# Matt Wszolek

### Location

Chicago, IL

### Academics

University of Illinois at Chicago

### Interests

- Embedded

### Development

- Software Engineer for SteelSeries

### Projects

- USB device with a screen

### Profile Link

[Matt Wszolek](https://github.com/mattwszolek)