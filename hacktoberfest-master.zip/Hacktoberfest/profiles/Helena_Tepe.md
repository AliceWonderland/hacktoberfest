# Helena Tepe

### Location

Brunswick/Germany

### Academics

TU Braunschweig

### Interests

- me

### Development

- hobby projects

### Projects

- none

### Profile Link

[h3l3n4](https://github.com/h3l3n4)
