# Prateek Pandey

### Location

Bangalore, India

### Academics

Undergraduated in Computer Science.

### Interests

- Coding
- AI and Machine learning
- Opensource Enthusiast

### Development

- Working as opensource software developer in OpenEBS which is opensource project.
- Contributing to other opensource projects i.e. Kubernetes etc.

### Projects

- [OpenEBS](https://github.com/openebs) Containerize strorage for containers http://openebs.io
- [Maya](https://github.com/openebs/maya) OpenEBS Storage orchestrator and infrastructure management engine
- [Kubernetes](https://github.com/kubernetes/kubernetes) Production-Grade Container Scheduling and Management http://kubernetes.io

### Profile Link

[Prateek Pandey](https://github.com/prateekpandey14/)
