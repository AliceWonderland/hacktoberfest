# Tanguy Labrador Ruiz

### Location

Brussels, Belgium

### Academics

Graduated into the field of Communication from ISFSC.
Two years of Computer Science at ESI.

### Interests

- Coffee
- Movies (What did you thinked about Blade Runner 2049?)
- Music (I'm listening to  [Radiohead playing live into the basement](https://www.youtube.com/watch?v=Xq_a8f24UJI) while writing this)
- Comics & mangas
- Gaming (add **Dirk3Diggler** on PSN if you'd like to play some Overwatch!)
- 
### Development

- Some school projects (Console version of **Rush Hour** made with **Java**, a unfinished **Uno 2D game** made with **Java/JavaFx** and another 2D graphics game, **Tetris, in **C++/Qt framework** and a **Checkers game**, also in **C++/Qt framework**).
- Currently working on a portfolio for hosting my future front-end projects, [please check it and give me any advice you have](https://codepen.io/tanguyLabradorRuiz/full/YryxaV/).
- Currently working on my ES6 JavaScript and learning React & Webpack.

### Projects

- [CPP-Checkers](https://github.com/TheMyopist/CPP-Checkers) 2D Checkers game using C++/QT, unfinished, code is messy and not fully documented.

### Profile Link

[Tanguy Labrador Ruiz aka TheMyopist](https://github.com/TheMyopist)
If you're near Brussels area, I'm looking for a job! Please check my [Linkedin page](https://www.linkedin.com/in/tanguy-labrador-ruiz-aa9757b7/).