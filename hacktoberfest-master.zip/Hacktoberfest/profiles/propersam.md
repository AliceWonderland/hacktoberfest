# Ameh Samuel

### Location

Lagos/Nigeria

###Academics

Bsc. Final Year in Computer Science
From UNIVERSITY OF NIGERIA, NSUKKA

### Interests

- Love to code
- Love to design
- Music is my thing
- Love Gaming

### Development

- Inventor of skynow
- I code most time in Python

### Profile Link

[Ameh Samuel](https://github.com/propersam)