# Marios Georgiou

### Location

Larnaca, Cyprus

### Academics

Middlesex University London, UK
Montclair State University, USA

### Interests

- Cooking
- Coding
- Thinking
- Creating
- Loving

### Development

- Java
- C++
- JavaScript
- Python
- php

### Projects

- Univeristy and independent projects

### Profile Link

[Marios' Github page](https://github.com/MariosGeorgiou)
