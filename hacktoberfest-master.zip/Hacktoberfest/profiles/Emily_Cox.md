# Emily Cox

### Location

Austin, Texas, United States

### Interests

- Reading
- Writing
- Yoga

### Development
- Learning Java in school. Learning JS and Python on my own. 


### Projects

- Just little things for school

### Profile Link

[Emily Cox](https://github.com/robotnamedEmily)
