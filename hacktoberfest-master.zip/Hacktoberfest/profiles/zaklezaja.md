# Zak Lezaja

### Location

UK

### Academics

University of Glasgow, Computer Science

### Interests

- Computers
- Artificial Intelligence
- Music production
- Sound design

### Languages

- Python
- Java

### Profile Link

[Zak Lezaja](https://github.com/zaklezaja)
