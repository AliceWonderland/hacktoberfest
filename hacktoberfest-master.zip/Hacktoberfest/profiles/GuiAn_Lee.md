# Gui An Lee

### Location

Singapore, Singapore

### Academics

Undergraduate in B.S. (Information Systems and Technology in Design) from Singapore University of Technology and Design

### Interests

- Game Mechanics and Systems
- Engineering and Interaction design
- Product Design and UX
- Memes

### Development

- Student

### Projects

- None so far

### Profile Link

[Gui An Lee](https://github.com/piroton )