# Aimee Tacchi

### Location

England, UK

## About me:

I'm a self-taught female Front-End Developer that loves creating beautiful stunning clean responsive websites.

### Development

- HTML/HTML5
- CSS, Sass, Bootstrap
- Javascript, jQuery, Angular
- Git

### Interests

- :airplane: Travelling
- :camera: Digital Photography
- :tea: Tea
- :smiley_cat: Cats
- :video_game: Anime & Games
- :art: Drawing and Art
- :leaves: Walking in the countryside
- :guitar: Rock Music

[Check out my GitHub](https://github.com/darkxangel84)

