# IzabelaM

### Location

Scotland, UK

### Academics

BSc Web Design & Development, 3rd year

### Interests

- User experience
- Data analysis
- Upholstery

### Profile Link

[IzabelaM](https://github.com/IzabelaM)
