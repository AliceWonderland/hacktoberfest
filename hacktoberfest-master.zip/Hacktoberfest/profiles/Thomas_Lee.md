# Thomas Lee

### Location

Seoul, Republic of Korea

### Academic

Computer Science and Engineering College of Seoul National University

### Interests

- Flight Simulator
- Python
- Rust
- Military

### Development

Make some tools for hobby

### Projects

- [sun-and-wallpaper](https://github.com/pbzweihander/sun-and-wallpaper) Change wallpaper based on sunrise & sunset time for Windows.

### Profile Link

[Github](https://github.com/pbzweihander)
[Website](https://pbzweihander.github.io)
[Twitter](https://twitter.com/pbzweihander)

