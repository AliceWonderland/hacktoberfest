<?php

// LANGUAGE: PHP
// AUTHOR: Alex Blum
// GITHUB: https://github.com/alexblum

echo 'Hello world !';

?>
