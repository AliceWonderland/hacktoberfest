// LANGUAGE: GO
// ENV: Go
// AUTHOR: Sourav Verma
// GITHUB: https://github.com/SrGrace

package main

import "fmt"

func main() {
	fmt.Printf("hello, world\n")
  	fmt.Printf("Lets go for a ride :)\n")
}
