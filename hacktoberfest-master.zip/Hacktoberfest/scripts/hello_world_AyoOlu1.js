// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Victor Oluwayemi
// GITHUB: https://github.com/AyoOlu1

console.log("Hello, World!");
