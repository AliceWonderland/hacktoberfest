// LANGUAGE: C++
// AUTHOR: Prince Mishra
// GITHUB: https://github.com/prince721
#include<bits/stdc++.h>
using namespace std;
int main(){
	cout<<"Hello World";
	return 0;
}
