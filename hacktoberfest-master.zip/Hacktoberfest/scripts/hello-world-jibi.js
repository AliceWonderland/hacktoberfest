// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Jibi John David
// GITHUB: https://github.com/jibijohndavid

console.log("Hello World") 
