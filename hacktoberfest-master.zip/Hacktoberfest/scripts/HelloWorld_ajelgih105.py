#language: Python 2.7
#Author: ajleigh105
#GITHUB: https://github.com/ajleigh105
print "Hello World!"
wait_key = raw_input()
