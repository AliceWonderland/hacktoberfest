// LANGUAGE: Elixir
// AUTHOR: Bryan Tylor
// GITHUB: https://github.com/bryantylor
// LINK: https://elixir-lang.org/

IO.puts "Hello World!"
