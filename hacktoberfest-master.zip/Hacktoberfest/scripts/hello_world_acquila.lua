-- LANGUAGE: Lua
-- GITHUB: https://github.com/DJAcquila
-- AUTHOR: Acquila Santos Rocha


print ("Hello, World!")