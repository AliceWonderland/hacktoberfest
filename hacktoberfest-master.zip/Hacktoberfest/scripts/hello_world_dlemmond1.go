// LANGUAGE: Go
// ENV: Go 1.8
// AUTHOR: Daniel Lemmond
// GITHUB: https://github.com/dlemmond1
package main

import "fmt"

func main() {
	fmt.Println("Hello, gophers!")
}