# AUTHOR: Andrew Pickham
# LANGUAGE: Python
# GITHUB: https://github.com/apickham

print("Hello, World!")