// LANGUAGE: Javascript
// AUTHOR: Deddy T
// GITHUB: https://github.com/Busterz

console.log('Hello World!');
console.log('It\'s nice to meet you!');
