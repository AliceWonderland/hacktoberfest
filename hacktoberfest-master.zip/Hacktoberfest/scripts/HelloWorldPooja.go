// LANGUAGE: Go
// AUTHOR: Pooja Sahore
// GITHUB: https://github.com/poojas16

package main
import "fmt"
func main() {
    fmt.Println("hello world")
}
