# LANGUAGE: Python
# ENV: Python 2
# AUTHOR: Aarushi Arya
# GITHUB: https://github.com/aarushi15002
print 'Hello World'
print 'By Aarushi'
