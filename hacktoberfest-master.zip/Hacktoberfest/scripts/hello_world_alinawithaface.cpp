// LANGUAGE: C++
// AUTHOR: Alina Christenbury
// GITHUB: https://github.com/AlinaWithAFace

#include <iostream>

int main() {
	std::cout << "Hello World!" << std::endl;
	return 0;
}