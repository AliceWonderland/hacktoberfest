# LANGUAGE: Python 3
# AUTHOR: Deddy T
# GITHUB: https://github.com/Busterz

user = input("Hi there, what's your name? ")
print ("Hello %s!") % user
print ("Hello World!")
