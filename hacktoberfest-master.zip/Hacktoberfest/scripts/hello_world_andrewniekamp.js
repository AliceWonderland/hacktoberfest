// Language: JavaScript
// ENV: Node.js
// AUTHOR: Andrew Niekamp
// GITHUB: https://github.com/andrewniekamp

console.log('Hello, World!');
