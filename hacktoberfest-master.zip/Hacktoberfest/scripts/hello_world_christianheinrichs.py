#!/usr/bin/env python3

## LANGUAGE: Python
## ENV: Native
## AUTHOR: Christian Heinrichs
## GITHUB: https://github.com/christianheinrichs

print("Hello, world!")
