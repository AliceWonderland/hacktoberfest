// LANGUAGE: C++
// AUTHOR: George Fotopoulos
// GITHUB: https://github.com/xorz57

#include <iostream>

using namespace std;

int main() {
	cout << "Hello, World!" << endl;
	return 0;
}
