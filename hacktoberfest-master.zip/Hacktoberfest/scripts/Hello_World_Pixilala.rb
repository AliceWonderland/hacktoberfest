##LANGUAGE: Ruby
## AUTHOR: Pixilala
## GITHUB : https://github.com/Pixilala
puts("Hello World!")
