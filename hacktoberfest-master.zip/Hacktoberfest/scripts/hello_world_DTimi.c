// LANGUAGE: C
// AUTOR: Timea Kinga Deák
// GITHUB: https://github.com/DTimi

#include <stdio.h>

int main(void)
{
  printf("Hello, World from Dublin!\n");
}
