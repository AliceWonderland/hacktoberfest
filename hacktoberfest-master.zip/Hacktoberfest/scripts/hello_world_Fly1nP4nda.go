// LANGUAGE: Go
// AUTHOR: Edwin Chui
// GITHUB: https://github.com/Fly1nP4nda

package main

import "fmt"

func main(){
	fmt.Println("Hello, World!")
}