// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Ben Smith
// GITHUB: https://github.com/ben-w-smith

console.log('Hello, World!');