# LANGUAGE: bash
# AUTHOR:       Akshat Maheshwari
# GITHUB:		https://github.com/akshat14714

#!/bin/bash
echo "Hello World! and Hello $USER"
