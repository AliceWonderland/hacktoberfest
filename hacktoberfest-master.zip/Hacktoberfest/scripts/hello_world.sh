# LANGUAGE: bash
# AUTHOR:		Robert Martin
# GITHUB:		https://github.com/rmartin5

#!/bin/bash
echo "Hello World! and hello $USER"
