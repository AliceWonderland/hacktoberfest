// LANGUAGE: Python
// ENV: Python 3.5
// AUTHOR: Lucas Marioza
// GITHUB: https://github.com/LucasMarioza
print("Hello World!")
