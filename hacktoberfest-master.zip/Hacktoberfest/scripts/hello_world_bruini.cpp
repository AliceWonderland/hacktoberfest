// Language: C++
// Author: Pedro Bruini
// GitHub: https://github.com/bruini

#include <iostream>

int main() {
    std::cout << "Hello, World!";
    return 0;
}