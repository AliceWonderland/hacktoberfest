# LANGUAGE (Interpreted): PowerShell
# ENV: Windows
# AUTHOR: tashrafy
# GITHUB: https://github.com/tashrafy

Write-Host Hello World