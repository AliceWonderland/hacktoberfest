// LANGUAGE: Java
// ENV: JVM
// AUTHOR: Rute Carrapato
// GITHUB: https://github.com/RuteCarrapato

public class Hello {

    public static void main(String[] args) {

        System.out.println("Hello World!!!!");
        
    }
}
