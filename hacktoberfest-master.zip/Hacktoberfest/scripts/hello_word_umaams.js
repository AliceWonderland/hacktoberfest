// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Khotibul Umam
// GITHUB: https://github.com/umaams

console.log("Hello, I'm Umam from Indonesia");