// LANGUAGE: Python
// ENV: IDLE
// AUTHOR: Pseudogenesis
// GITHUB: https://github.com/pseudogenesis 
print("Hello world~")
