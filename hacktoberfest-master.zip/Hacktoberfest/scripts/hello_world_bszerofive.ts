// LANGUAGE: TypeScript
// ENV: Node.js
// AUTHOR: bsZeroFive
// GITHUB: https://github.com/bsZeroFive

console.log('Hello, world!');