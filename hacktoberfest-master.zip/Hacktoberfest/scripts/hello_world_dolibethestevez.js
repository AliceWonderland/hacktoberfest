// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Dolibeth Estevez
// GITHUB: https://github.com/dolibethestevez

console.log('Hello, World!');
