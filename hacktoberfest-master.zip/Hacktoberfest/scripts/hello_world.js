// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: JIA WEI
// GITHUB: https://github.com/heyjiawei

console.log('Hello, World!');