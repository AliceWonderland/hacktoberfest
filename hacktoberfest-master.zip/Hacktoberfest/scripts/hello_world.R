myString <- "Hello, World!"

print ( myString)
