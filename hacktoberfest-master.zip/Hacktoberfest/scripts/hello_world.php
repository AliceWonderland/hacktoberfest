<?php 
/** 
* LANGUAGE: PHP
* ENV: PHP/Apache/Nginx
* AUTHOR: Junior Oliveira, Billy Lee
* GITHUB: https://github.com/arojunior, https://github.com/leebilly0
*/
echo "Hello World!";

?>
