
// LANGUAGE: javascript
// AUTHOR: brian richards
// GITHUB: https://github.com/brichards99

console.log('Hi there, World!');
