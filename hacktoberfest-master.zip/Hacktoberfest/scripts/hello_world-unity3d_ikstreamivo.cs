// LANGUAGE: C#
// ENV: Unity3D
// AUTHOR: Ivo Ketelaar
// GITHUB: https://github.com/IKStreamIvo

using UnityEngine;

public class HelloWorld : MonoBehaviour
{
    void Start()
    {
        Debug.Log("Hello, World!");
    }
}