// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Ben Hancock
// GITHUB: https://github.com/benhancockco/

const greeting = "Hello World";

console.log(greeting);
