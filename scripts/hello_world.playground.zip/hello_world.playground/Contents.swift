//language: SwiftUI
//Env: Xcode
//AUTHOR: Atharva
//Github: https://github.com/erbmu

import Cocoa

print("Hello World")
print("Kaladin says hi")
